# LocalDemo

![](http://7xiew0.com1.z0.glb.clouddn.com/locale_0.gif)


DEMO来自于[iOS国际化](http://mokai.github.io/2015/10/iOS国际化)，功能主要是切换语言后相应的界面文字&图片以及搜索引擎都会随语言变化。


